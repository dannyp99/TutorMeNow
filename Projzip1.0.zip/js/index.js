$(document).ready(function() {
  $('#contact-form').submit(function(e) {
    var name    = document.getElementById('name')
    var scid = document.getElementById('scid')
    var loc   = document.getElementById('location')
    var subject = document.getElementById('subject')
    var prof = document.getElementById('prof')
    var email = document.getElementById('email')

    if (!name.value || !scid.value|| !loc.value || !subject.value || !prof.value || !email.value) {
      alertify.error("Please check your entries");
      return false;
    } else {
      e.preventDefault();
      $(this).get(0).reset();
      alertify.success("Request Sent");
    }
    if(!name.value)
    	alertify.error("Please enter your Name");
    else if(!scid.value)
      	alertify.error("Please enter your School I.D.");
    else if(!loc.value)
      	alertify.error("Please choose a Tutoring Location");
    else if(!subject.value)
      	alertify.error("Please choose a Subject");
    else if(!prof.value)
      	alertify.error("
  });
});



